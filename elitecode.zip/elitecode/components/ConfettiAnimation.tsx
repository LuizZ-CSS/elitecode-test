import React from 'react';
import ConfettiCannon from 'react-native-confetti-cannon';

const ConfettiAnimation = () => {
  return <ConfettiCannon count={200} origin={{ x: 0, y: 0 }} />;
};

export default ConfettiAnimation;
