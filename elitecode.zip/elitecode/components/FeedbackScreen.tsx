import React from 'react';
import { View, Text, TouchableOpacity } from 'react-native';
import ConfettiAnimation from './ConfettiAnimation'; // Import confetti animation

const FeedbackScreen = ({ isCorrect }: { isCorrect: boolean }) => {
  return (
    <View>
      {isCorrect ? (
        <View>
          <Text>Congratulations, you earned a badge!</Text>
          <ConfettiAnimation />
        </View>
      ) : (
        <View>
          <Text>Oops! Try again.</Text>
        </View>
      )}
      <TouchableOpacity onPress={() => {/* Retry logic */}}>
        <Text>Retry</Text>
      </TouchableOpacity>
    </View>
  );
};

export default FeedbackScreen;
