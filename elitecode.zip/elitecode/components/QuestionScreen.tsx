import React, { useState } from 'react';
import { View, Text, TouchableOpacity } from 'react-native';
import styles from '../styles/globalStyles';

const QuestionScreen = () => {
  const [selectedAnswer, setSelectedAnswer] = useState(null);

  const handleSubmit = () => {
    // Handle answer validation here or in a hook
  };

  return (
    <View>
      <Text style={styles.questionText}>What is the output of the following code?</Text>
      <TouchableOpacity onPress={() => setSelectedAnswer('122')}>
        <Text>122</Text>
      </TouchableOpacity>
      {/* Add more answer options and Submit button */}
    </View>
  );
};

export default QuestionScreen;
