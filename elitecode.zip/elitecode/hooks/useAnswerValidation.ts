import { useState } from 'react';

const useAnswerValidation = (correctAnswer: string) => {
  const [isCorrect, setIsCorrect] = useState(null);

  const validateAnswer = (selectedAnswer: string) => {
    setIsCorrect(selectedAnswer === correctAnswer);
  };

  return { isCorrect, validateAnswer };
};

export default useAnswerValidation;
