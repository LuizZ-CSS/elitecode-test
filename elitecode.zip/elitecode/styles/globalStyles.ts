import { StyleSheet } from 'react-native';

const styles = StyleSheet.create({
  questionText: {
    fontSize: 18,
    marginBottom: 20,
  },
  // Define other styles here
});

export default styles;
